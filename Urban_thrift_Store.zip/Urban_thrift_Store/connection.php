<?php 
 $connection=mysqli_connect("localhost","root","Reddy@123","data");
 ?>
