<?php
include "connection.php";

$firstname =mysqli_real_escape_string($connection,$_POST['fname']);
$secondname=mysqli_real_escape_string($connection,$_POST['sname']);
$email = mysqli_real_escape_string($connection,$_POST['email']);
$password =mysqli_real_escape_string($connection,$_POST['password']);
$creat="CREATE TABLE form1(firstnamee VARCHAR(20) NOT NULL,lastnamee VARCHAR(20) NOT NULL,EMAIL VARCHAR(40) NOT NULL,PASSWORD  VARCHAR(50) NOT NULL);";
if(mysqli_query($connection,$creat)){
	echo "table created successfully";
}
else{
	echo "not creted";
}
//$query= "INSERT INTO form VALUES ('$firstname', '$secondname', '$email', '$password');";
//$p=mysqli_query($connect,$query);
//if($p){
	//echo "insertion successfull";
//}
//else{
	//echo "no insertion";
//}
    
//$query = "SELECT * FROM form;";
//$check = mysqli_query($connection, $query);
//if (mysqli_num_rows($check)) {
    //while ($row = mysqli_fetch_assoc($check)) {
       //echo $row['firstname']." ".$row['secondname']." ".$row['email']." ".$row['password']." "<br>;
    //}
//}
//header("Location:form.html");
//echo $firstname;

?>
